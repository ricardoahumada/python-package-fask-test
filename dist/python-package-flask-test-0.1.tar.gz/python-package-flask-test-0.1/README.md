"# python-package-flask-test" 

## Lauch the app
- py runserver

## Test execution
- py -m unittest discover -s tests\acceptance -v